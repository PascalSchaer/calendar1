import { useState } from 'react';
import Calendar from 'react-calendar';
import './App.css';
import './Calendar.css';

function App() {
  const [date, setDate] = useState(new Date());

  return (
    <div className='app'>
      <div>
        <img src="./equipment.png" alt='equipment'/>
        <h1 className='text-center'>Strength Journal</h1>
      </div>
      <div className='calendar-container'>
        <Calendar onChange={setDate} value={date} />
      </div>
      <p className='text-center'>
        <span className='bold'>Selected Date:</span>{' '}
        {date.toDateString()}
      </p>
      <button className='workout-button'>Add a Workout</button>
    </div>
  );
}

export default App;